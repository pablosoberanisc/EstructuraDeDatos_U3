from Funciones import create_linked_list
